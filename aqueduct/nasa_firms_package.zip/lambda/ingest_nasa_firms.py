import json
import os

import requests


def lambda_handler(event, context):
    date = "2023-11-06"
    country = "NZL"
    source = "MODIS_NRT"
    map_key = os.environ["NASA_FIRMS_MAP_KEY"]
    day_range = 1
    if date:
        url = f"https://firms.modaps.eosdis.nasa.gov/api/{country}/csv/{map_key}/{source}/{day_range}/{date}"
    else:
        url = f"https://firms.modaps.eosdis.nasa.gov/api/{country}/csv/{map_key}/{source}/{day_range}"
    response = requests.get(url)
    lines = response.content.decode("utf-8").splitlines()
    data = [line.split(",") for line in lines]
    headers = data[0]
    rows = data[1:]
    json_data = [dict(zip(headers, row)) for row in rows]
    return {"status_code": 200, "body": json_data}
